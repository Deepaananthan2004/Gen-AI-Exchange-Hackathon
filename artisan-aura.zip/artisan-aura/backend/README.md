# Artisan Aura Backend

- 🎙️ Whisper → transcription
- 😊 Emotion detection
- ✍️ Story generation
- 🌐 Translation

Run locally:
```bash
cd backend
uvicorn main:app --reload
```
