# Artisan Aura 🎙️🌍

Voice → Story → Translation → AR Crafts

## Run Backend
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

## Run Frontend
```bash
cd frontend
npm install
npm run dev
```

Open: http://127.0.0.1:5173
